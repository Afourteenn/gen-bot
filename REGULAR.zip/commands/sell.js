const { MessageEmbed, Message } = require('discord.js');
const config = require('../config.json');

module.exports = {
  name: 'sell',
  description: 'People who sell prem',

  execute(message) {
    const { commands } = message.client;

    message.channel.send(
      new MessageEmbed()
        .setColor(config.color.default)
        .setTitle('Sellers')
        .setDescription('**doom (2$)  **')
        .setFooter(message.author.tag, message.author.displayAvatarURL({ dynamic: true, size: 64 }))
        .setTimestamp()
    );
  }
};
print("made by doom dont claim its urs u loser")