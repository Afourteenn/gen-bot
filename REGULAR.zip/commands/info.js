const { MessageEmbed, Message } = require('discord.js');
const config = require('../config.json');

module.exports = {
  name: 'info',
  description: 'info idfk',

  execute(message) {
    const { commands } = message.client;

    message.channel.send(
      new MessageEmbed()
        .setColor(config.color.default)
        .setTitle('Info Of lay.rip')
        .setDescription('lay.rip is coming soon. **YOU CAN PURCHASE A SPOT ON THE SITE AND GET A ROLE!**')
        .setFooter(message.author.tag, message.author.displayAvatarURL({ dynamic: true, size: 64 }))
        .setTimestamp()
    );
  }
};
print("made by doom dont claim its urs u loser")